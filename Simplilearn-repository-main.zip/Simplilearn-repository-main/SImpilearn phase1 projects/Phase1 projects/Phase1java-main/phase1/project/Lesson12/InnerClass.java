package phase1.project.Lesson12;

public class InnerClass {




	public static void main(String[] args) {
		Rohith r = new Rohith() {
			
			@Override
			public void krish() {
				System.out.println("annonymous inner class");// Anonymous inner classes
			}
		};
		r.krish();
		
		Pavan pa = new Pavan();
		pa.home(new Rohith() {
			@Override
			public void krish() {
				System.out.println();
				System.out.println("Argument based annonymous inner class");
			}
			
		});
		
		System.out.println();
		
		new outer().new inner().print();
		
		System.out.println();
		
		

	}

}


interface Rohith{
	void krish();
}


class Pavan {
	void home(Rohith ref) {
	ref.krish();}
}

class outer{
	class inner{
		void print() {
			System.out.println("Regular inner class");
		}
	}
}



class Outer{
	void func() {
		class Inner{
			void print() {
				System.out.println("Method local inner class");
			}
		}
		new Inner().print();
	}
}