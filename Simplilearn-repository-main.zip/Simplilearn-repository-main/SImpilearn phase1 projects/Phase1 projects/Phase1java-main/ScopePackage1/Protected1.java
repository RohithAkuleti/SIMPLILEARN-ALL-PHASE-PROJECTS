package ScopePackage1;

import ScopePackage.*;

public class Protected1 extends Protected {


 

	public static void main(String[] args) {
		Protected1 pro = new Protected1();
		pro.display();
		//displaying private method of another class

	}

}