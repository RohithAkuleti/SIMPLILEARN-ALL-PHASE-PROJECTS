package ScopePackage1;


public class Public1  {
	public void display() {
		System.out.println("The public Access Specifier in testPackage1");
	}

}
