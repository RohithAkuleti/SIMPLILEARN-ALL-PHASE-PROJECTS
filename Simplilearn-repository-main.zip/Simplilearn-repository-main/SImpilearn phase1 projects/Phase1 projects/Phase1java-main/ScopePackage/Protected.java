package ScopePackage;

public class Protected {




	protected void display() {
		System.out.println("Protected access specifier in package Protected1");
	}

}