package ScopePackage;

public class Public {
	public void display() {
		System.out.println("The public Access Specifier in testPackage1");
	}

}
