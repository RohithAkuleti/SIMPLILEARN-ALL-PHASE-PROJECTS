package org.simplilearn.workshop.spring_Assignment;

public record Transfer() {

}
